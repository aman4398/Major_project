jQuery(document).ready(function(){

    
    $('#input-win-panel').focusout(function(){

        
        
        var sourceName = 'Testcase1';
        var sourceCode =  $('#input-win').val();
        
        var sourceLang = "";
        savePath = './input';
                return $.ajax({
                    method: 'POST',
                    url: "saveFile",
                    data: {
                        'sourceCode': sourceCode,
                        'sourceLang': sourceLang,
                        'sourceName': sourceName,
                        'remotePath': savePath
                    },
                    error: function(data) {
                        new $.Zebra_Dialog("Error occured while saving: " + "<br><br>" + data.responseText, {
                            'buttons': false,
                            'modal': false,
                            'position': ['right - 20', 'top + 20'],
                            'auto_close': 1500,
                            'type': 'error',
                            'title': 'Testcase unsaved'
                        });
                    }
                });
    });

});

